package com.ates.moneytransfer.controller;

import static spark.Spark.delete;
import static spark.Spark.get;
import static spark.Spark.port;
import static spark.Spark.post;
import static spark.Spark.put;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import com.ates.moneytransfer.service.AccountService;
import com.ates.moneytransfer.service.TransferService;
import com.ates.moneytransfer.util.JsonUtil;
import com.ates.moneytransfer.model.Account;
import com.ates.moneytransfer.model.Transfer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import spark.Spark;

public class ProcessController {
	
    private static ObjectMapper om = new ObjectMapper();
    
    private static final AtomicInteger COUNTER = new AtomicInteger();
	
	public ProcessController() {

        final AccountService accountService = new AccountService();

		
		 // Start embedded server at this port
        port(8282);


        final TransferService transferService = new TransferService();
 
        // Main Page, welcome
        get("/", (request, response) -> "Welcome money transfer application / created by Ibrahim Ates");

 
        // GET - get account with this id
        Spark.get("/api/accounts/:id", (request, response) -> {
            Account account = accountService.findById(Integer.valueOf(request.params(":id")));
            if (account != null) {
                return om.writeValueAsString(account);
            } else {
                response.status(404); // 404 Not found
                return om.writeValueAsString("account with id " + Integer.valueOf(request.params(":id") + " is not found "));
            }
        });
 
        // Get - list all accounts
        
        Spark.get("/api/accounts", (request, response) -> {
            List result = accountService.findAll();
            if (result.isEmpty()) {
                return om.writeValueAsString("accounts not found");
            } else {
                return om.writeValueAsString(accountService.findAll());
            }
        }, JsonUtil.json());

        // POST - Add an account
        Spark.post("/api/accounts", (request, response) -> {
            Gson gson = new GsonBuilder().create();
            Account account2 = gson.fromJson(request.body() , Account.class);
            if(account2.getName()!=null&account2.getBalance().compareTo(BigDecimal.ZERO)>=0)
            {
                accountService.addAccount(account2);
                response.status(201); // 201 Created
                om.writeValueAsString(account2);

            }
            else
            {
                response.status(400); // Bad Request
                if(account2.getName()==null || account2.getName()=="")
                {
                    om.writeValueAsString("account's name can not be empty");
                }
                else if(account2.getBalance().compareTo(BigDecimal.ZERO)<0)
                {
                    om.writeValueAsString("account's balance can not be less than 0");

                }

            }
            return om;


        }, JsonUtil.json());
 
        // PUT - Update account
        Spark.put("/api/accounts/:id", (request, response) -> {
            int id = Integer.valueOf(request.params(":id"));
            Account account = accountService.findById(Integer.valueOf(request.params(":id")));
            if (account != null) {
            	
            	Gson gson = new GsonBuilder().create();
                Account account2 = gson.fromJson(request.body() , Account.class);
                
                accountService.updateAccount(id, account2);
                return om.writeValueAsString("acount with id " + id + " is updated!");
            } else {
                response.status(404);
                return om.writeValueAsString("account with id " + id + " is not found to update");
            }
        }, JsonUtil.json());
 
        // DELETE - delete account
        Spark.delete("/api/accounts/:id", (request, response) -> {
        	 int id = Integer.valueOf(request.params(":id"));
             Account account = accountService.findById(Integer.valueOf(request.params(":id")));
             if (account != null) {
                accountService.delete(id);
                return om.writeValueAsString("account with id " + id + " is deleted!");
            } else {
                response.status(404);
                return om.writeValueAsString("account with id " + id + " is not found to delete!");
            }
        }, JsonUtil.json());


        // POST - Add an transfer
        Spark.post("/api/transfers", (request, response) -> {
            Gson gson = new GsonBuilder().create();
            Transfer transfer = gson.fromJson(request.body() , Transfer.class);

            Transfer transfer2 = transferService.addTransfer(transfer);
            if(transfer2.getStatus()== Transfer.TransferStatus.CREATED)
            {
                response.status(201); // 201 Created
                om.writeValueAsString(transfer);
            }
            else
            {
                response.status(400); // bad request
                if(transfer2.getStatus()== Transfer.TransferStatus.AMOUNTZERO) {
                    om.writeValueAsString("Because transfer amount is zero, process can not be proceed. Please check your information!");
                }
                else if(transfer2.getStatus()== Transfer.TransferStatus.AMOUNTLESS){
                    om.writeValueAsString("Balance is less than amount you want send. Please check your information!");

                }
                else if(transfer2.getStatus()== Transfer.TransferStatus.FROMIDNULL){
                    om.writeValueAsString("id that you send money can not be null. Please check your information!");
                }
                else if(transfer2.getStatus()== Transfer.TransferStatus.TOIDNULL){
                    om.writeValueAsString("sender id can not be null. Please check your information!");
                }


            }
            return om;


        }, JsonUtil.json());

        // GET - get transfer with this id
        Spark.get("/api/transfers/:id", (request, response) -> {
            Transfer transfer = transferService.findById(Integer.valueOf(request.params(":id")));
            if (transfer != null) {
                return om.writeValueAsString(transfer);
            } else {
                response.status(404); // 404 Not found
                return om.writeValueAsString("transfer not found");
            }
        }, JsonUtil.json());

        // Get - list all transfers

        Spark.get("/api/transfers", (request, response) -> {
            List result = transferService.findAll();
            if (result.isEmpty()) {
                return om.writeValueAsString("No transfers done yet");
            } else {
                return om.writeValueAsString(transferService.findAll());
            }
        }, JsonUtil.json());

        // PUT - Update transfer
        Spark.put("/api/transfers/:id", (request, response) -> {
            int id = Integer.valueOf(request.params(":id"));
            Transfer transfer = transferService.findById(Integer.valueOf(request.params(":id")));
            if (transfer != null) {

                Gson gson = new GsonBuilder().create();
                Transfer transfer2 = gson.fromJson(request.body() , Transfer.class);

                Transfer transfer3 = transferService.updateTransfer(id, transfer2);
                if(transfer3.getStatus()== Transfer.TransferStatus.UPDATED)
                {
                    response.status(200); // 200 Ok
                    om.writeValueAsString("transfer with id " + id + " is updated!");
                }
                else
                {
                    response.status(400); //
                    if(transfer2.getStatus()== Transfer.TransferStatus.AMOUNTZERO) {
                        om.writeValueAsString("Because transfer amount is zero, process can not be proceed. Please check your information!");
                    }
                    else if(transfer2.getStatus()== Transfer.TransferStatus.AMOUNTLESS){
                        om.writeValueAsString("Balance is less than amount you want send. Please check your information!");

                    }
                    else if(transfer2.getStatus()== Transfer.TransferStatus.FROMIDNULL){
                        om.writeValueAsString("id that you send money can not be null. Please check your information!");
                    }
                    else if(transfer2.getStatus()== Transfer.TransferStatus.TOIDNULL){
                        om.writeValueAsString("sender id can not be null. Please check your information!");
                    }


                }
                return om;

            } else {
                response.status(404);
                return om.writeValueAsString("Any transfer wants to update not found");
            }
        }, JsonUtil.json());

    }

}
