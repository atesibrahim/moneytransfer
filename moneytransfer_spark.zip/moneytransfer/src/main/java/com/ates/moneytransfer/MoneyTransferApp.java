package com.ates.moneytransfer;

import com.ates.moneytransfer.controller.ProcessController;

public class MoneyTransferApp
{
	
    
    public static void main( String[] args )
    {
        new ProcessController();

    } 
}
