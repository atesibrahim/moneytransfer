package com.ates.moneytransfer;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import com.jayway.restassured.RestAssured;

import static com.jayway.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class MoneyTransferAppTest {


    @BeforeClass
    public static void setUp() throws Exception{
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8282;
    }

    @AfterClass
    public static void unconfigureRestAssured() {
        RestAssured.reset();
    }

    @Test
    public void testListAllAccounts() {
        final int id = get("/api/accounts").then()
                .assertThat()
                .statusCode(200)
                .extract()
                .jsonPath().getInt("find { it.balance==2560 }.id");

        get("/api/accounts/" + id).then()
                .assertThat()
                .statusCode(200)
                .body("accountId", equalTo(id))
                .body("name", equalTo("halil"));
    }

    @Test
    public void testReadOneAccountSuccess() {
        get("/api/accounts/0").then()
                .assertThat()
                .statusCode(200)
                .body("accountId", equalTo(0))
                .body("name", equalTo("ibrahim"));
    }

    @Test
    public void testReadOneAccountFail() {
        get("/api/accounts/10").then()
                .assertThat()
                .statusCode(404);
    }

    @Test
    public void testAddAccountSuccess() {
        given().body("{\n" +
                "    \"name\": \"iha\",\n" +
                "    \"balance\": \"6000\",\n" +
                "}")
                .when()
                .post("api/accounts")
                .then()
                .assertThat()
                .statusCode(201);
    }

    @Test
    public void testAddAccountFail() {
        given().body("{\n" +
                "    \"name\": \"iha\",\n" +
                "    \"balance\": \"-20\",\n" +
                "}")
                .when()
                .post("api/accounts")
                .then()
                .assertThat()
                .statusCode(400);
    }

    @Test
    public void testUpdateAccountSuccess() {
        given().body("{\n" +
                "    \"balance\": \"500\",\n" +
                "}")
                .when()
                .put("api/accounts/0")
                .then()
                .assertThat()
                .statusCode(200)
                .body("accountId", equalTo(0))
                .body("name", equalTo("ibrahim"))
                .body("balance", equalTo(500));
    }

    @Test
    public void testUpdateAccountFail() {
        given().body("{\n" +
                "    \"balance\": \"-20\"\n" +
                "}")
                .when()
                .put("api/accounts/0")
                .then()
                .assertThat()
                .statusCode(400);
    }

    @Test
    public void testDeleteOneAccountSucces() {
        delete("/api/accounts/0").then()
                .assertThat()
                .statusCode(204);
        get("/api/accounts/0").then()
                .assertThat()
                .statusCode(404);
    }

    @Test
    public void testDeleteOneAccountFail() {
        delete("/api/accounts/999").then()
                .assertThat()
                .statusCode(404);
    }

    @Test
    public void testRetrieveAllTransfers() {
        final int id = get("/api/transfers").then()
                .assertThat()
                .statusCode(200)
                .extract()
                .jsonPath().getInt("find { it.amount==23 }.id");
        get("/api/transfers/" + id).then()
                .assertThat()
                .statusCode(200)
                .body("id", equalTo(id))
                .body("fromAccountId", equalTo(0))
                .body("toAccountId", equalTo(1))
                .body("amount", equalTo(23))
                .body("comment", equalTo("make transfer"));
    }

    @Test
    public void testReadTransferSuccess() {
        get("/api/transfers/0").then()
                .assertThat()
                .statusCode(200)
                .body("id", equalTo(1))
                .body("fromAccountId", equalTo(0))
                .body("toAccountId", equalTo(1))
                .body("amount", equalTo(55));
    }

    @Test
    public void testReadTransferFail() {
        get("/api/transfers/999").then()
                .assertThat()
                .statusCode(404);
    }

    @Test
    public void testAddTransferSuccess() {
        given().body("{\n" +
                "    \"toAccountId\": \"1\",\n" +
                "    \"fromAccountId\": \"0\",\n" +
                "    \"amount\": \"250\",\n" +
                "    \"comment\": \"test transfer\"\n" +
                "}")
                .when()
                .post("api/transfers")
                .then()
                .assertThat()
                .statusCode(201);
    }

    @Test
    public void testAddTransferFail() {
        given().body("{\n" +
                "    \"toAccountId\": \"1\",\n" +
                "    \"fromAccountId\": \"0\",\n" +
                "    \"amount\": \"1000000\",\n" +
                "    \"comment\": \"test transfer\"\n" +
                "}")
                .when()
                .post("api/transfers")
                .then()
                .assertThat()
                .statusCode(400);
    }

    @Test
    public void testUpdateTransferSuccess() {
        given().body("{\n" +
                "    \"toAccountId\": \"1\",\n" +
                "    \"fromAccountId\": \"0\",\n" +
                "    \"amount\": \"100\",\n" +
                "    \"comment\": \"update transfer\"\n" +
                "}")
                .when()
                .put("api/transfers/0")
                .then()
                .assertThat()
                .statusCode(400);
    }

    @Test
    public void testUpdateTransferFail() {
        given().body("{\n" +
                "    \"toAccountId\": \"1\",\n" +
                "    \"fromAccountId\": \"0\",\n" +
                "    \"amount\": \"100\",\n" +
                "    \"comment\": \"update transfer\"\n" +
                "}")
                .when()
                .put("api/transfers/5")
                .then()
                .assertThat()
                .statusCode(404);
    }
}
