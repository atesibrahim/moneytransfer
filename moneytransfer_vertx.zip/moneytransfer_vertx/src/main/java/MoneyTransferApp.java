
import data.CreateInitData;
import io.vertx.config.ConfigRetriever;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Launcher;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;
import io.vertx.ext.web.handler.StaticHandler;
import model.Account;
import model.Transfer;

import java.math.BigDecimal;

public class MoneyTransferApp extends AbstractVerticle {

    // For creation first data, following class will initalized.
    CreateInitData createInitData = new CreateInitData();


    public static void main(String[] args) {
        Launcher.executeCommand("run", MoneyTransferApp.class.getName());
    }

    @Override
    public void start(Future<Void> startFuture) throws Exception {

        // For creation first data, method will called.
        createInitData.createData();


        // A router receives request from an HttpServer and routes it to
        // the first matching Route that it contains. A router can contain many routes. ref: vertx.io
        Router router = Router.router(vertx);


        // for root address when you type it(ex: http://localhost:8181/). Message welcomes you like following.
        router.route("/").handler(routingContext -> {
            HttpServerResponse response = routingContext.response();
            response
                    .putHeader("content-type", "text/html")
                    .end("<h1>Money Transfer/by Ibrahim Ates</h1>");
        });

        // If you have any .html file under resources then if you want to open that file
        // you must type address example: http://localhost:8181/assets/index.html

        router.route("/assets/*").handler(StaticHandler.create("assets"));
        router.route().handler(BodyHandler.create());

        // For add, update, delete, list operations
        router.get("/api/accounts").handler(this::listAllAccounts);
        router.get("/api/accounts/:id").handler(this::getAccount);
        router.put("/api/accounts/:id").handler(this::updateAccount);
        router.post("/api/accounts").handler(this::addAccount);
        router.delete("/api/accounts/:id").handler(this::deleteAccount);

        router.get("/api/transfers").handler(this::listAllTransfers);
        router.get("/api/transfers/:id").handler(this::getTransfer);
        router.put("/api/transfers/:id").handler(this::updateTransfer);
        router.post("/api/transfers").handler(this::createTransfer);


        // ConfigRetriever: Defines a configuration retriever that read configuration from ConfigStore and tracks changes periodically. ref: vertx.io
        // ConfigRetriever.create: Creates an instance of the default implementation of the ConfigRetriever. ref: vertx.io

        ConfigRetriever retriever = ConfigRetriever.create(vertx);

        retriever.getConfig(
                config -> {
                    if (config.failed()) {
                        startFuture.fail(config.cause());
                    } else {
                        // Create the HTTP server and pass the "accept" method to the request handler.
                        vertx
                                .createHttpServer()
                                .requestHandler(router::accept)
                                .listen(
                                        // Retrieve the port from the configuration,
                                        // default to 8080.
                                        config.result().getInteger("HTTP_PORT", 8181),
                                        result -> {
                                            if (result.succeeded()) {
                                                startFuture.complete();
                                            } else {
                                                startFuture.fail(result.cause());
                                            }
                                        }
                                );
                    }
                }
        );
    }

    private void listAllAccounts(RoutingContext routingContext) {
        routingContext.response()
                .putHeader("content-type", "application/json; charset=utf-8")
                .end(Json.encodePrettily(createInitData.accounts.values()));
    }

    private void getAccount(RoutingContext routingContext) {

        String id = routingContext.request().getParam("id");

        if (id == null)
        {

            routingContext.response().setStatusCode(400).end();

        } else {

            final Integer idAsInteger = Integer.valueOf(id);

            Account account = createInitData.accounts.get(idAsInteger);

            if (account == null)
            {
                routingContext.response().setStatusCode(404).end();
            }
            else {
                routingContext.response()
                        .putHeader("content-type", "application/json; charset=utf-8")
                        .end(Json.encodePrettily(account));
            }
        }
    }

    // If want to update account information
    private void updateAccount(RoutingContext routingContext) {

        String id = routingContext.request().getParam("id");
        JsonObject json = routingContext.getBodyAsJson();

        if (id == null || json == null) {

            // this is bad request
            routingContext.response().setStatusCode(400).end();
        }
        else {

            // wrapped integer to Integer
            Integer idAsInteger = Integer.valueOf(id);

            // find account by giving id
            Account account = createInitData.accounts.get(idAsInteger);

            if (account == null) {

                // if account not found return 404
                routingContext.response().setStatusCode(404).end();

            } else {

                // return account information, format json to string.
                boolean updated = false;
                if (json.getString("name") != null && !json.getString("name").isEmpty()) {
                    account.setName(json.getString("name"));
                    updated = true;
                }
                if (json.getString("balance") != null && !json.getString("balance").isEmpty() && (new BigDecimal(json.getString("balance"))).compareTo(BigDecimal.ZERO) >= 0) {
                    account.setBalance(new BigDecimal(json.getString("balance")));
                    updated = true;
                }
                if (!updated) {
                    routingContext.response().setStatusCode(400).end();
                } else {
                    routingContext.response()
                            .putHeader("content-type", "application/json; charset=utf-8")
                            .end(Json.encodePrettily(account));
                }
            }
        }
    }

    // If want to add account information
    private void addAccount(RoutingContext routingContext) {
        try {
            Account account = Json.decodeValue(routingContext.getBodyAsString(),
                    Account.class);

            createInitData.accounts.put(account.getAccountId(), account);

            routingContext.response()
                    .setStatusCode(201)
                    .putHeader("content-type", "application/json; charset=utf-8")
                    .end(Json.encodePrettily(account));
        } catch (Exception e) {

            // this is bad request.

            routingContext.response().setStatusCode(400).end();
        }
    }

    // If want to delete account information
    private void deleteAccount(RoutingContext routingContext) {
        String id = routingContext.request().getParam("id");
        if (id == null)
        {
            // return bad request.

            routingContext.response().setStatusCode(400).end();

        }
        else if (createInitData.accounts.get(Integer.valueOf(id)) == null)
        {
            // not found
            routingContext.response().setStatusCode(404).end();

        } else
            {
            Integer idAsInteger = Integer.valueOf(id);
            createInitData.accounts.remove(idAsInteger);
            routingContext.response().setStatusCode(204).end();
        }
    }

    // If want to list all transfers
    private void listAllTransfers(RoutingContext routingContext)
    {
        routingContext.response()
                .putHeader("content-type", "application/json; charset=utf-8")
                .end(Json.encodePrettily(createInitData.transfers.values()));
    }

    // If want to get transfer information
    private void getTransfer(RoutingContext routingContext) {

        String id = routingContext.request().getParam("id");

        if (id == null) {

            routingContext.response().setStatusCode(400).end();

        }
        else {
            final Integer idAsInteger = Integer.valueOf(id);

            Transfer transfer = createInitData.transfers.get(idAsInteger);

            if (transfer == null)
            {
                routingContext.response().setStatusCode(404).end();
            }
            else {
                routingContext.response()
                        .putHeader("content-type", "application/json; charset=utf-8")
                        .end(Json.encodePrettily(transfer));
            }
        }
    }

    // If want to update transfer information
    private void updateTransfer(RoutingContext routingContext) {

        String id = routingContext.request().getParam("id");

        if (id == null)
        {
            routingContext.response().setStatusCode(400).end();
        }
        else {
            Integer idAsInteger = Integer.valueOf(id);
            Transfer transfer = createInitData.transfers.get(idAsInteger);
            if (transfer == null)
            {
                // wrong request. Not found return
                routingContext.response().setStatusCode(404).end();
            }
            else {
                // check input and existence info and update data if ok input, else return error message
                if (transfer.getTransferAmount().compareTo(BigDecimal.ZERO) > 0 &&
                        createInitData.accounts.get(transfer.getFromAccountId()) != null &&
                        createInitData.accounts.get(transfer.getToAccountId()) != null &&
                        createInitData.accounts.get(transfer.getFromAccountId()).getBalance().compareTo(transfer.getTransferAmount()) >= 0)
                {

                   createInitData.accounts.get(transfer.getFromAccountId()).withdraw(transfer.getTransferAmount());
                   createInitData.accounts.get(transfer.getToAccountId()).deposit(transfer.getTransferAmount());

                }
                else {

                    // error message will be here.
                }
                routingContext.response()
                        .putHeader("content-type", "application/json; charset=utf-8")
                        .end(Json.encodePrettily(transfer));
            }
        }
    }

    // If want to create a new transfer
    private void createTransfer(RoutingContext routingContext) {
        try {

            Transfer transfer = Json.decodeValue(routingContext.getBodyAsString(),
                    Transfer.class);

            createInitData.transfers.put(transfer.getId(), transfer);

            routingContext.response()
                    .setStatusCode(201)
                    .putHeader("content-type", "application/json; charset=utf-8")
                    .end(Json.encodePrettily(transfer));
        }
        catch (Exception e) {
            routingContext.response().setStatusCode(400).end();
        }
    }



}
