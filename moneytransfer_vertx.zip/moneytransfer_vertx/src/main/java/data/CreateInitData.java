package data;

import model.Account;
import model.Transfer;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

public class CreateInitData {

    public final Map<Integer, Account> accounts = new LinkedHashMap();
    public final Map<Integer, Transfer> transfers = new LinkedHashMap();

    public void createData(){

        Account account = new Account(0,"ibrahim", BigDecimal.valueOf(1460));
        accounts.put(0, account);
        Account account2 = new Account(1,"halil", BigDecimal.valueOf(2560));
        accounts.put(1, account2);
        Account account3 = new Account(2,"ates", BigDecimal.valueOf(6964));
        accounts.put(2, account3);


        Transfer transfer = new Transfer(0, 1, BigDecimal.valueOf(100));
        transfers.put(0, transfer);
        Transfer transfer2 = new Transfer(1, 2, BigDecimal.valueOf(50));
        transfers.put(1, transfer2);
        Transfer transfer3 = new Transfer(2, 60, BigDecimal.valueOf(40));
        transfers.put(2, transfer3);

    }
}
