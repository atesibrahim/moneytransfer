package model;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicInteger;

public class Transfer {

    private static final AtomicInteger COUNTER = new AtomicInteger();

    private int id;

    private int fromAccountId;

    private int toAccountId;

    private BigDecimal transferAmount;


    public Transfer(int fromAccountId, int toAccountId, BigDecimal transferAmount) {

        this.id=COUNTER.getAndIncrement();
        this.fromAccountId = fromAccountId;
        this.toAccountId = toAccountId;
        this.transferAmount = transferAmount;
    }

    public int getId() {
        return id;
    }

    public int getFromAccountId() {
        return fromAccountId;
    }

    public void setFromAccountId(int fromAccountId) {
        this.fromAccountId = fromAccountId;
    }

    public int getToAccountId() {
        return toAccountId;
    }

    public void setToAccountId(int toAccountId) {
        this.toAccountId = toAccountId;
    }

    public BigDecimal getTransferAmount() {
        return transferAmount;
    }

    public void setTransferAmount(BigDecimal transferAmount) {
        this.transferAmount = transferAmount;
    }



    @Override
    public String toString() {
        return "Transfer{" +
                "id=" + id +
                ", fromAccountId=" + fromAccountId +
                ", toAccountId=" + toAccountId +
                ", transferAmount=" + transferAmount +
                '}';
    }
}
